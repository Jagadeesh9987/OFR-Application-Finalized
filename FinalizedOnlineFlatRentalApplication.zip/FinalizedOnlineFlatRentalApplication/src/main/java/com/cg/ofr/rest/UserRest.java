package com.cg.ofr.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ofr.entities.User;
import com.cg.ofr.exception.EntityNotFoundException;
import com.cg.ofr.service.IUserService;

@RestController
public class UserRest {

	@Autowired
	private IUserService iUserServiceImpl;

	@GetMapping("/user/{id}")
	public User viewUser(@PathVariable Integer id) throws EntityNotFoundException {
		return iUserServiceImpl.viewUser(id);
	}

	@GetMapping("/users")
	public List<User> viewAllUser() {
		return iUserServiceImpl.viewAllUser();
	}

	@GetMapping("/validate/{username}/{password}")
	public User validateUser(@PathVariable String username, @PathVariable String password) throws EntityNotFoundException {
		return iUserServiceImpl.validateUser(username, password);
	}

	@PostMapping("/user")
	public User addUser(@RequestBody User user) {
		return iUserServiceImpl.addUser(user);
	}

	@PutMapping("/user")
	public User updateUser(@RequestBody User user) {
		return iUserServiceImpl.updateUser(user);
	}

	@PutMapping("/password/{newpass}")
	public User updatePassword(@RequestBody User user, @PathVariable String newpass) throws EntityNotFoundException {
		return iUserServiceImpl.updatePassword(user, newpass);
	}

	@DeleteMapping("/user")
	public User removeUser(@RequestBody User user) {
		return iUserServiceImpl.removeUser(user);
	}

}
