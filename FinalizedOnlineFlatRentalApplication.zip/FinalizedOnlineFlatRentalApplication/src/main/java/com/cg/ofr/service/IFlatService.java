package com.cg.ofr.service;

import java.util.List;

import com.cg.ofr.entities.Flat;
import com.cg.ofr.exception.EntityNotFoundException;

public interface IFlatService {
	public Flat addFlat(Flat flat);

	public Flat updateFlat(Flat flat);

	public Flat deleteFlat(Flat flat);

	public Flat viewFlat(int id) throws EntityNotFoundException;

	public List<Flat> viewAllFlat();

	public List<Flat> viewAllFlatByCost(float cost, String availability);
}
