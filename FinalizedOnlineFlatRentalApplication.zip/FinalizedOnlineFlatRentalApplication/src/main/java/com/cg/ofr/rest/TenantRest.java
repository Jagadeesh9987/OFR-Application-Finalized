package com.cg.ofr.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ofr.entities.Tenant;
import com.cg.ofr.exception.EntityNotFoundException;
import com.cg.ofr.service.ITenantService;

import io.swagger.annotations.Api;

@Api(value = "Swagger2DemoRestController")
@RestController
public class TenantRest {

	@Autowired
	private ITenantService iTenantService;

	@PostMapping("/tenant")
	public Tenant addTenant(@RequestBody Tenant tenant) {
		Tenant tenant2 = null;
		tenant2 = this.iTenantService.addTenant(tenant);
		return tenant2;
	}

	@PutMapping("/tenant")
	public Tenant updateTenant(@RequestBody Tenant tenant) {
		Tenant tenant2 = null;
		tenant2 = this.iTenantService.updateTenant(tenant);
		return tenant2;
	}

	@DeleteMapping("/tenant")
	public Tenant deleteTenant(@RequestBody Tenant tenant) {
		Tenant tenant2 = null;
		tenant2 = this.iTenantService.deleteTenant(tenant);
		return tenant2;
	}

	@GetMapping("/tenant/{id}")
	public Tenant viewTenant(@PathVariable("id") Integer id) throws EntityNotFoundException {
		Tenant tenant = this.iTenantService.viewTenant(id);
		return tenant;
	}

	@GetMapping("/tenants")
	public List<Tenant> viewAllTenant() {
		List<Tenant> tenants = this.iTenantService.viewAllTenant();
		return tenants;
	}

	@GetMapping("/tenantexist")
	public Tenant validateTenant(@RequestBody Tenant tenant) {
		Tenant tenant2 = null;
		tenant2 = this.iTenantService.validateTenant(tenant);
		return tenant2;
	}

}